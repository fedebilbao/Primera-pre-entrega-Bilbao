from setuptools import setup

setup(
    name = "Entregas",
    version = "1.0",
    description = "Primer paquete distribuido de mis entregas",
    author = "Federico Bilbao",
    author_email = "fedebilbao3@gmail.com",
    packages = ["Entregas"]
)